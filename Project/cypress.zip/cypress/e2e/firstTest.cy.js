describe('CLOWIZ', () => {
  it('renders default element on screen', () => {
    cy.visit(' http://localhost:5173/');
    cy.get('[data-testid="cypress-title"]')
    .should("exist")
    .should('have.text',"CLOWIZ")
    ;
  })
});


it('should have the input fields for CLO descriptions and questions', () => {
  cy.visit('http://localhost:5173/');

  // Verify presence of input fields
  cy.get('textarea[placeholder="CLOS Name - Description"]').should('exist');
  cy.get('textarea[placeholder="Question"]').should('exist');

  // Verify input fields cannot be empty
  cy.get('textarea[placeholder="CLOS Name - Description"]').clear();
  cy.get('textarea[placeholder="Question"]').clear();

  cy.get('.btn').click();
  
  // Verify error messages for empty input fields
  cy.on('window:alert', (message) => {
    expect(message).to.contain('CLOS Name - Description cannot be empty');
    expect(message).to.contain('Question cannot be empty');
  });
});
// verify functionality of sort button
it('should navigate to the Result page when the "SORT" button is clicked', () => {
  cy.visit('http://localhost:5173/');
  cy.get('.textarea-style')
    .first()
    .type('CLO1: Master the Fundamentals of Mixed Martial Arts, Acquire a deep understanding of the core techniques, strategies, and principles of mixed martial arts (MMA)');
  cy.get('.textarea-style')
    .last()
    .type('How do you define the fundamentals of MMA?');
  cy.get('.btn').click();
  // cy.url().should('include', '/Result');
 cy.visit('http://localhost:5173/Result');
  cy.wait(1000);
    
});

// it('should handle the error when the backend server is unavailable', () => {
//   cy.intercept('POST', 'http://localhost:5173/predict', {
//     statusCode: 500,
//     body: {},
//   }).as('predictRequest');

//   cy.visit('http://localhost:5173/');
//   cy.get('.textarea-style')
//     .first()
//     .type('CLO1: Master the Fundamentals of Mixed Martial Arts, Acquire a deep understanding of the core techniques, strategies, and principles of mixed martial arts (MMA)');
//   cy.get('.textarea-style')
//     .last()
//     .type('How do you define the fundamentals of MMA?');
//   cy.get('.btn').click();
//   cy.wait('@predictRequest');

//   // Verify the error handling, e.g., display an error message
//   cy.on('window:alert', (message) => {
//     expect(message).to.contain('Error occurred');
//   });
// });

