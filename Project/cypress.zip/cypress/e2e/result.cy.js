describe('Result Page', () => {
  beforeEach(() => {
    // Simulate the data being available in session storage
    const resultData = {
      questions: {
        'What are the core principles of mixed martial arts (MMA)?': 'CLO1: Master the Fundamentals of Mixed Martial Arts',
        'How do you define the fundamentals of MMA?': 'CLO1: Master the Fundamentals of Mixed Martial Arts',
        'Can you explain the importance of understanding MMA techniques and strategies?': 'CLO6: Understand Fight Strategies',
        'What are some common striking techniques used in MMA?': 'CLO2: Develop Proficiency in Striking Techniques',
        'How do you practice and improve your punching skills in MMA?': 'CLO2: Develop Proficiency in Striking Techniques',
        'What are the key differences between various types of kicks in MMA?': 'CLO2: Develop Proficiency in Striking Techniques',
        'How do you analyze your opponent\'s fighting style in MMA?': 'CLO6: Understand Fight Strategies',
        'What are some common fight strategies used in MMA matches?': 'CLO6: Understand Fight Strategies',
        'Can you discuss the importance of adapting your strategy during a fight in MMA?': 'CLO6: Understand Fight Strategies',
      },
    };
    sessionStorage.setItem('resultData', JSON.stringify(resultData));
    cy.visit('http://localhost:5173/Result');
  });

  it('should display the processed questions and their associated CLOs', () => {
    cy.get('table tbody tr').should('have.length', 9);

    cy.get('table tbody tr:first td:first').should('have.text', 'CLO1: Master the Fundamentals of Mixed Martial Arts');
    cy.get('table tbody tr:first td:last').should('have.text', 'What are the core principles of mixed martial arts (MMA)?');

    cy.get('table tbody tr:nth-child(2) td:first').should('have.text', 'CLO1: Master the Fundamentals of Mixed Martial Arts');
    cy.get('table tbody tr:nth-child(2) td:last').should('have.text', 'How do you define the fundamentals of MMA?');

    cy.get('table tbody tr:nth-child(3) td:first').should('have.text', 'CLO6: Understand Fight Strategies');
    cy.get('table tbody tr:nth-child(3) td:last').should('have.text', 'Can you explain the importance of understanding MMA techniques and strategies?');

    cy.get('table tbody tr:nth-child(4) td:first').should('have.text', 'CLO2: Develop Proficiency in Striking Techniques');
    cy.get('table tbody tr:nth-child(4) td:last').should('have.text', 'What are some common striking techniques used in MMA?');

    cy.get('table tbody tr:nth-child(5) td:first').should('have.text', 'CLO2: Develop Proficiency in Striking Techniques');
    cy.get('table tbody tr:nth-child(5) td:last').should('have.text', 'How do you practice and improve your punching skills in MMA?');

    cy.get('table tbody tr:nth-child(6) td:first').should('have.text', 'CLO2: Develop Proficiency in Striking Techniques');
    cy.get('table tbody tr:nth-child(6) td:last').should('have.text', 'What are the key differences between various types of kicks in MMA?');

    cy.get('table tbody tr:nth-child(7) td:first').should('have.text', 'CLO6: Understand Fight Strategies');
    cy.get('table tbody tr:nth-child(7) td:last').should('have.text', 'How do you analyze your opponent\'s fighting style in MMA?');

    cy.get('table tbody tr:nth-child(8) td:first').should('have.text', 'CLO6: Understand Fight Strategies');
    cy.get('table tbody tr:nth-child(8) td:last').should('have.text', 'What are some common fight strategies used in MMA matches?');

    cy.get('table tbody tr:nth-child(9) td:first').should('have.text', 'CLO6: Understand Fight Strategies');
    cy.get('table tbody tr:nth-child(9) td:last').should('have.text', 'Can you discuss the importance of adapting your strategy during a fight in MMA?');
    cy.wait(3000);
  });

  it('should navigate to the Sort page when the "SORT AGAIN" button is clicked', () => {
    cy.get('.btn').click();
    cy.url().should('include', '/Sort');
  });

 
});